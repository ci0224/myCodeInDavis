package sexpr

import (
	"math/big"
	"testing"
)

func buildNilExample() *SExpr {
	return mkNil()
}

func buildNumberExample() *SExpr {
	return mkNumber(big.NewInt(100))
}

func buildSymbolExample() *SExpr {
	return mkSymbol("+")
}

func buildConsCellExample() *SExpr {
	return mkConsCell(mkSymbol("A"), mkSymbol("B"))
}

func buildProperListExample() *SExpr {
	return mkConsCell(mkSymbol("A"), mkConsCell(mkSymbol("B"), mkConsCell(mkSymbol("C"), mkNil())))
}

func buildDottedListExample() *SExpr {
	return mkConsCell(mkSymbol("A"), mkConsCell(mkSymbol("B"), mkSymbol("C")))
}

func buildQuoteExample() *SExpr {
	return mkConsCell(mkSymbol("QUOTE"), mkConsCell(mkSymbol("A"), mkNil()))
}

type SExprBuilder func() *SExpr

func TestParseExample(t *testing.T) {
	for idx, test := range []struct {
		input                string
		expectedSExprBuilder SExprBuilder
	}{
		{"()", buildNilExample},
		{"100", buildNumberExample},
		{"+", buildSymbolExample},
		{"(A . B)", buildConsCellExample},
		{"(A B C)", buildProperListExample},
		{"(A B . C)", buildDottedListExample},
		{"'A", buildQuoteExample},
	} {
		actual, err := NewParser().Parse(test.input)
		expected := test.expectedSExprBuilder()
		if err != nil {
			t.Errorf("\nin test %d\nunexpected error", idx)
			continue
		}
		if actual.SExprString() != expected.SExprString() {
			t.Errorf("\nin test %d (\"%s\")\nerror: got      %s\n       expected %s",
				idx, test.input, actual.SExprString(), expected.SExprString())
		}
	}
}

func TestParserInvalid(t *testing.T) {
	for idx, test := range []string{
		"",
		"(",
		"'",
		")",
		"x)",
		"( ) ( )",
		"(a . () . () . ())",
		"((x .",
		"(x",
		"(a x ')",
		"(' .)",
		"(#",
		"(a . #",
		"( (2) #",
	} {
		_, err := NewParser().Parse(test)
		if err == nil {
			t.Errorf("\nin test %d\nshould error", idx)
		}
	}
}

func TestParserProperList(t *testing.T) {
	for idx, test := range []struct {
		input, expectedSExprString string
	}{
		{"()", "NIL"},
		{"a", "A"},

		// proper lists
		{"(())", "(NIL . NIL)"},
		{"(a)", "(A . NIL)"},
		{"((a))", "((A . NIL) . NIL)"},
		{"(a b c)", "(A . (B . (C . NIL)))"},
		{"(a b c d)", "(A . (B . (C . (D . NIL))))"},
		{"(  a b c  d  e)", "(A . (B . (C . (D . (E . NIL)))))"},
		{"(  (a b )c)", "((A . (B . NIL)) . (C . NIL))"},
		{"(a b (c d))", "(A . (B . ((C . (D . NIL)) . NIL)))"},
		{"(a () () a)", "(A . (NIL . (NIL . (A . NIL))))"},

		// dotted lists
		{"(a (b . c))", "(A . ((B . C) . NIL))"},
		{"(a . b)", "(A . B)"},
		{"(a . (b . c))", "(A . (B . C))"},
		{"(a . (b . (c . d)))", "(A . (B . (C . D)))"},
		{"(a . ((b . c) . d))", "(A . ((B . C) . D))"},
		{"(a b . c)", "(A . (B . C))"},
		{"(a b c . d)", "(A . (B . (C . D)))"},
		{"(a (b c) d . e)", "(A . ((B . (C . NIL)) . (D . E)))"},
		{"(a b (c d) . e)", "(A . (B . ((C . (D . NIL)) . E)))"},
		{"(a b c . (d e))", "(A . (B . (C . (D . (E . NIL)))))"},
		{"(a b c . (d . e))", "(A . (B . (C . (D . E))))"},
		{"(a(b.c  ))", "(A . ((B . C) . NIL))"},
		{"(a . ( (  ) . ( ( ) . a)))", "(A . (NIL . (NIL . A)))"},
	} {
		actual, err := NewParser().Parse(test.input)
		if err != nil {
			t.Errorf("\nin test %d\nunexpected error", idx)
			continue
		}
		if actual.SExprString() != test.expectedSExprString {
			t.Errorf("\nin test %d (\"%s\")\nerror: got      %s\n       expected %s",
				idx, test.input, actual.SExprString(), test.expectedSExprString)
		}
	}
}

func TestParseQuote(t *testing.T) {
	for idx, test := range []struct {
		input, expectedSExpr string
	}{
		{"'(1 2)", "(QUOTE . ((1 . (2 . NIL)) . NIL))"},
		{"'(1 . 2)", "(QUOTE . ((1 . 2) . NIL))"},
		{"(quote . (1 . 2))", "(QUOTE . (1 . 2))"},
		{"'a", "(QUOTE . (A . NIL))"},
		{"'(a)", "(QUOTE . ((A . NIL) . NIL))"},
		{"''a", "(QUOTE . ((QUOTE . (A . NIL)) . NIL))"},
		{"''(a)", "(QUOTE . ((QUOTE . ((A . NIL) . NIL)) . NIL))"},
		{"(' a 'b '  c)", "((QUOTE . (A . NIL)) . ((QUOTE . (B . NIL)) . ((QUOTE . (C . NIL)) . NIL)))"},
	} {
		actual, _ := NewParser().Parse(test.input)
		if actual.SExprString() != test.expectedSExpr {
			t.Errorf("\nerror: in test %d (\"%s\"):\n\texpected: %s\n\tgot      %s",
				idx, test.input, test.expectedSExpr, actual.SExprString())
		}
	}
}

// for sexpr+lexer

func TestSExprNil1(t *testing.T) {
	se := mkNil()
	if !se.isNil() {
		t.Errorf("expected isNil() to return true")
	}
	if !se.isAtom() {
		t.Errorf("expected isAtom() to return true")
	}
	if !se.isConsCell() {
		t.Errorf("expected isConsCell() to return true")
	}
	if se.isNumber() {
		t.Errorf("expected isNumber() to return false")
	}
	if se.isSymbol() {
		t.Errorf("expected isSymbol() to return false")
	}
	if se.SExprString() != "NIL" {
		t.Errorf("incorrect SExprString()")
	}
}

func TestSExprAtom1(t *testing.T) {
	se := mkAtom(mkTokenSymbol("A"))
	if se.isNil() {
		t.Errorf("expected isNil() to return false")
	}
	if !se.isAtom() {
		t.Errorf("expected isAtom() to return true")
	}
	if se.isConsCell() {
		t.Errorf("expected isConsCell() to return false")
	}
	if se.SExprString() != "A" {
		t.Errorf("incorrect SExprString()")
	}
}

func TestSExprNumber1(t *testing.T) {
	se := mkNumber(big.NewInt(100))
	if se.isNil() {
		t.Errorf("expected isNil() to return false")
	}
	if !se.isAtom() {
		t.Errorf("expected isAtom() to return true")
	}
	if se.isConsCell() {
		t.Errorf("expected isConsCell() to return false")
	}
	if !se.isNumber() {
		t.Errorf("expected isNumber() to return true")
	}
	if se.isSymbol() {
		t.Errorf("expected isSymbol() to return false")
	}
	if se.SExprString() != "100" {
		t.Errorf("incorrect SExprString()")
	}
}

func TestSExprSymbol1(t *testing.T) {
	se := mkSymbol("+")
	if se.isNil() {
		t.Errorf("expected isNil() to return false")
	}
	if !se.isAtom() {
		t.Errorf("expected isAtom() to return true")
	}
	if se.isConsCell() {
		t.Errorf("expected isConsCell() to return false")
	}
	if se.isNumber() {
		t.Errorf("expected isNumber() to return false")
	}
	if !se.isSymbol() {
		t.Errorf("expected isSymbol() to return true")
	}
	if se.SExprString() != "+" {
		t.Errorf("incorrect SExprString()")
	}
}

func TestSExprSymbolTrue1(t *testing.T) {
	se := mkSymbolTrue()
	if se.isNil() {
		t.Errorf("expected isNil() to return false")
	}
	if !se.isAtom() {
		t.Errorf("expected isAtom() to return true")
	}
	if se.isConsCell() {
		t.Errorf("expected isConsCell() to return false")
	}
	if se.isNumber() {
		t.Errorf("expected isNumber() to return false")
	}
	if !se.isSymbol() {
		t.Errorf("expected isSymbol() to return true")
	}
	if se.SExprString() != "T" {
		t.Errorf("incorrect SExprString()")
	}
}

func TestSExprConsCell1(t *testing.T) {
	se := mkConsCell(mkSymbol("A"), mkSymbol("B"))
	if se.isNil() {
		t.Errorf("expected isNil() to return false")
	}
	if se.isAtom() {
		t.Errorf("expected isAtom() to return false")
	}
	if !se.isConsCell() {
		t.Errorf("expected isConsCell() to return true")
	}
	if se.isNumber() {
		t.Errorf("expected isNumber() to return false")
	}
	if se.isSymbol() {
		t.Errorf("expected isSymbol() to return false")
	}
	if se.SExprString() != "(A . B)" {
		t.Errorf("incorrect SExprString()")
	}
}

// Simple tests for tokenizing strings with a single token.
func TestLexerValidTokens2(t *testing.T) {
	tests := []struct {
		input       string
		expectedTok *token
	}{
		// end-of-file, left paranthesis, right parantsis and comma tokens
		{"", mkTokenEOF()},
		{"(", mkTokenLpar()},
		{")", mkTokenRpar()},
		{".", mkTokenDot()},

		// `mkTokenQuote()` returns the special `'` notation of `QUOTE`
		{"'", mkTokenQuote()},

		// `mkTokenSymbol("QUOTE")` returns the symbol `QUOTE`
		{"QUOTE", mkTokenSymbol("QUOTE")},
		{"quoTE", mkTokenSymbol("QUOTE")},
		{"qUoTe", mkTokenSymbol("QUOTE")},
		{"quote", mkTokenSymbol("QUOTE")},

		// example of valid number tokens
		{"0", mkTokenNumber("0")},
		{"1", mkTokenNumber("1")},
		{"00001", mkTokenNumber("1")},
		{"+00001", mkTokenNumber("1")},
		{"-00001", mkTokenNumber("-1")},
		{"1234567890", mkTokenNumber("1234567890")},
		{
			"10000000000000000000000000000000000000000000000000",
			mkTokenNumber("10000000000000000000000000000000000000000000000000"),
		},
		{
			"-10000000000000000000000000000000000000000000000000",
			mkTokenNumber("-10000000000000000000000000000000000000000000000000"),
		},

		// example of valid symbol tokens
		{"+", mkTokenSymbol("+")},
		{"*", mkTokenSymbol("*")},
		{"atom", mkTokenSymbol("ATOM")},
		{"zerop", mkTokenSymbol("ZEROP")},

		{"nil", mkTokenSymbol("NIL")},
		{"nIl", mkTokenSymbol("NIL")},
		{"Nil", mkTokenSymbol("NIL")},
		{"NIL", mkTokenSymbol("NIL")},

		{"t", mkTokenSymbol("T")},
		{"T", mkTokenSymbol("T")},

		{"foo", mkTokenSymbol("FOO")},
		{"isValidAtom", mkTokenSymbol("ISVALIDATOM")},
		{"is-valid-atom", mkTokenSymbol("IS-VALID-ATOM")},
		{"random_token_0123_", mkTokenSymbol("RANDOM_TOKEN_0123_")},
		{"X", mkTokenSymbol("X")},
		{"Var1", mkTokenSymbol("VAR1")},
		{"_A_", mkTokenSymbol("_A_")},
		{"___Y__2_", mkTokenSymbol("___Y__2_")},
	}
	for idx, test := range tests {
		func() {
			defer func() {
				if r := recover(); r != nil {
					t.Errorf("\nin test %d (\"%s\") panic: %s", idx, test.input, r)
				}
			}()
			lex := newLexer(test.input)
			tok, err := lex.next()
			tok.String()
			if err != nil {
				t.Errorf("\nin test %d (\"%s\"): lexer got an unexpected error %#v when tokenizing a valid input %#v", idx, test.input, err, test.input)
			}
			if !equalToken(tok, test.expectedTok) {
				t.Errorf("\nin test %d (\"%s\"):\n\texpected token %#v\n\tgot token      %#v", idx, test.input, test.expectedTok, tok)
			}
		}()
	}
}

// TestLexerInvalidTokens tests that the lexer does not token invalid strings.
func TestLexerInvalidTokens2(t *testing.T) {
	invalidStrings := []string{
		// Example of some invalid symbols in terms
		",",
		"\"",
		"=",
		"#",
		"$",
		"%",
		":",
	}
	for idx, input := range invalidStrings {
		func() {
			defer func() {
				if r := recover(); r != nil {
					t.Errorf("\nin test %d (\"%s\") panic: %s", idx, input, r)
				}
			}()
			if _, err := newLexer(input).next(); err != ErrLexer {
				t.Errorf("\nin test %d (\"%s\"): lexer did not get error %#v when tokenizing an invalid input %#v",
					idx, input, ErrLexer, input)
			}
		}()
	}
}

func TestLexerSequence2(t *testing.T) {
	// `newLexer(str)` returns a new lexer with given input string.
	input := " (zerop (  +  +1 '+2 (quote -3))) "
	lex := newLexer(input)
	// The expected sequence of literals when calling lex.next()
	expectedTokens := []*token{
		mkTokenLpar(),
		mkTokenSymbol("ZEROP"),
		mkTokenLpar(),
		mkTokenSymbol("+"),
		mkTokenNumber("1"),
		mkTokenQuote(),
		mkTokenNumber("2"),
		mkTokenLpar(),
		mkTokenSymbol("QUOTE"),
		mkTokenNumber("-3"),
		mkTokenRpar(),
		mkTokenRpar(),
		mkTokenRpar(),
		mkTokenEOF(),
		mkTokenEOF(),
	}
	for idx, expectedToken := range expectedTokens {
		// `lex.next()` consumes the input string, skips spaces and returns the next
		// token.
		token, err := lex.next()
		if err != nil {
			t.Errorf("lexer got an unexpected error %#v when tokenizing a valid input", err)
		}
		if token == nil {
			t.Errorf("lexer returned an unexpected nil token")
		}
		if !equalToken(token, expectedToken) {
			t.Errorf("\nin %d-th token of input \"%s\":\n\texpected token %#v\n\tgot token      %#v", idx, input, expectedToken, token)
		}
	}
}
