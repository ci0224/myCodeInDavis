package sexpr

import "errors"

// ErrParser is the error value returned by the Parser if the string is not a
// valid term.
// See also https://golang.org/pkg/errors/#New
// and // https://golang.org/pkg/builtin/#error
var ErrParser = errors.New("parser error")

//
// <sexpr>       ::= <atom> | <pars> | QUOTE <sexpr>
// <atom>        ::= NUMBER | SYMBOL
// <pars>        ::= LPAR <dotted_list> RPAR | LPAR <proper_list> RPAR
// <dotted_list> ::= <proper_list> <sexpr> DOT <sexpr>
// <proper_list> ::= <sexpr> <proper_list> | \epsilon
//

type Parser interface {
	Parse(string) (*SExpr, error)
}

func NewParser() Parser {
	return &Parse{
		lex:     nil,
		peekTok: nil,
	}
}

type Parse struct {
	lex     *lexer
	peekTok *token
}

func (p *Parse) nextToken() (*token, error) {
	if tok := p.peekTok; tok != nil {
		p.peekTok = nil
		return tok, nil
	}
	return p.lex.next()
}

func (p *Parse) backToken(tok *token) {
	p.peekTok = tok
}

func (p *Parse) Parse(input string) (*SExpr, error) {
	p.lex = newLexer(input)
	p.peekTok = nil

	token, err := p.nextToken()

	if err != nil || token.typ == tokenEOF {
		return nil, ErrParser
	}
	p.backToken(token)

	sexpr, err := p.NextSexpr()
	if err != nil {
		return nil, ErrParser
	}

	if token, err := p.nextToken(); err != nil || token.typ != tokenEOF {
		return nil, ErrParser
	}
	return sexpr, nil
}

func (p *Parse) mkSimpleSexpr(tok *token, car *SExpr, cdr *SExpr) *SExpr {
	return &SExpr{atom: tok, car: car, cdr: cdr}
}

func (p *Parse) mkComplexSexpr(tok *token, car *SExpr, cdr *SExpr) *SExpr {
	return &SExpr{atom: tok, car: car, cdr: cdr}
}

func (p *Parse) NextSexpr() (*SExpr, error) {
	token, err := p.nextToken()
	if err != nil {
		return nil, ErrParser
	}

	switch token.typ {
	case tokenSymbol:
		return p.mkSimpleSexpr(token, nil, nil), nil
	case tokenNumber:
		return p.mkSimpleSexpr(token, nil, nil), nil
	case tokenEOF:
		return nil, nil
	case tokenQuote:
		s := p.mkSimpleSexpr(token, nil, nil)
		next, err := p.nextToken()
		if err != nil || next.typ == tokenRpar || next.typ == tokenEOF {
			return nil, ErrParser
		}
		p.backToken(next)
		arg, err := p.NextSexpr()
		if err != nil {
			return nil, err
		}
		return p.mkComplexSexpr(s.atom, s, p.mkComplexSexpr(arg.atom, arg, p.mkSimpleSexpr(nil, nil, nil))), nil

	case tokenLpar:
		next, err := p.nextToken()
		if err != nil {
			return nil, err
		}
		if next.typ == tokenRpar {
			return p.mkSimpleSexpr(nil, nil, nil), nil
		}
		if next.typ == tokenEOF {
			return nil, ErrParser
		}

		p.backToken(next)
		arg, err := p.NextSexpr()
		if err != nil {
			return nil, err
		}

		next, err = p.nextToken()
		args := []*SExpr{arg}
		foundDot := []bool{true}

		if err != nil {
			return nil, ErrParser
		}

		for ; next.typ != tokenEOF && next.typ != tokenRpar; next, err = p.nextToken() {
			if next.typ == tokenDot {
				arg, err = p.NextSexpr()
				if err != nil {
					return nil, err
				}

				if arg == nil || (arg.atom == nil && arg.cdr == nil) {
					return nil, ErrParser
				}

				foundDot = foundDot[:len(foundDot)-1]
				temp := args[len(args)-1]

				args = args[:len(args)-1]
				args = append(args, p.mkComplexSexpr(temp.atom, temp, arg))
				foundDot = append(foundDot, false)
			} else {
				p.backToken(next)
				arg, err = p.NextSexpr()
				if err != nil {
					return nil, err
				}
				args = append(args, arg)
				foundDot = append(foundDot, true)
			}
		}

		if err != nil || next.typ != tokenRpar {
			return nil, ErrParser
		}
		if len(args) == 1 {
			if foundDot[len(foundDot)-1] {
				arg = p.mkSimpleSexpr(nil, nil, nil)
				return p.mkComplexSexpr(args[0].atom, args[0], arg), nil
			} else {
				return args[0], nil
			}
		}
		if foundDot[len(foundDot)-1] {
			arg = p.mkSimpleSexpr(nil, nil, nil)
			args[len(args)-1] = p.mkComplexSexpr(args[len(args)-1].atom, args[len(args)-1], arg)
		}
		for i := len(args) - 2; i >= 1; i-- {
			if foundDot[i] {
				args[i] = p.mkComplexSexpr(args[i].atom, args[i], args[i+1])
			}
		}
		return p.mkComplexSexpr(args[0].atom, args[0], args[1]), nil
	default:
		return nil, ErrParser

	}
}
