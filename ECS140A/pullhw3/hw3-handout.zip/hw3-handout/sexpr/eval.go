package sexpr

import (
	"errors"
	"math/big" // You will need to use this package in your implementation.
)

// ErrEval is the error value returned by the Evaluator if the contains
// an invalid token.
// See also https://golang.org/pkg/errors/#New
// and // https://golang.org/pkg/builtin/#error
var ErrEval = errors.New("eval error")
var track = 0

func (expr *SExpr) Eval() (*SExpr, error) {
	if expr.car == nil && expr.cdr == nil && (expr.atom == nil || expr.atom.literal == "NIL") {
		return expr, nil
	}

	if expr.atom.typ == tokenNumber {
		if track == 0 && expr.cdr != nil {
			return nil, ErrEval
		}
		if expr.cdr == nil {
			return expr, nil
		} else {
			tok := &token{typ: tokenNumber, num: expr.atom.num}
			return &SExpr{atom: tok, car: nil, cdr: nil}, nil
		}
	}

	if expr.atom.typ == tokenSymbol {

		// arithmetic operations
		if expr.atom.literal == "+" {
			if expr.cdr != nil {
				sum := big.NewInt(0)
				if !expr.car.isAtom() {
					track++
					stmt, err := expr.car.Eval()
					track--
					if err != nil || stmt.atom.typ != tokenNumber {
						return nil, ErrEval
					}
					sum.Add(sum, stmt.atom.num)
				} else {
					newExpr := expr.cdr
					if newExpr.car != nil && newExpr.car.atom.typ != tokenNumber {
						track++
						stmt, err := newExpr.car.Eval()
						track--
						if err != nil || stmt.atom.typ != tokenNumber {
							return nil, ErrEval
						}
						sum.Add(sum, stmt.atom.num)
						newExpr = newExpr.cdr
					}
					for newExpr != nil {
						if newExpr.atom == nil {
							break
						}
						track++
						stmt, err := newExpr.Eval()
						track--
						if err != nil || stmt.atom.typ != tokenNumber {
							return nil, ErrEval
						}
						sum.Add(sum, stmt.atom.num)
						newExpr = newExpr.cdr
					}
				}
				tok := &token{typ: tokenNumber, num: sum}
				return &SExpr{atom: tok, car: nil, cdr: nil}, nil
			} else {
				return nil, ErrEval
			}
		}
		if expr.atom.literal == "*" {
			if expr.cdr != nil {
				sum := big.NewInt(1)
				if !expr.car.isAtom() {
					track++
					stmt, err := expr.car.Eval()
					track--
					if err != nil || stmt.atom.typ != tokenNumber {
						return nil, ErrEval
					}
					sum.Mul(sum, stmt.atom.num)
				} else {
					newExpr := expr.cdr
					if newExpr.car != nil && newExpr.car.atom.typ != tokenNumber {
						track++
						stmt, err := newExpr.car.Eval()
						track--
						if err != nil || stmt.atom.typ != tokenNumber {
							return nil, ErrEval
						}
						sum.Mul(sum, stmt.atom.num)
						newExpr = newExpr.cdr
					}
					for newExpr != nil {
						if newExpr.atom == nil {
							break
						}
						track++
						stmt, err := newExpr.Eval()
						track--
						if err != nil || stmt.atom.typ != tokenNumber {
							return nil, ErrEval
						}
						sum.Mul(sum, stmt.atom.num)
						newExpr = newExpr.cdr
					}
				}
				tok := &token{typ: tokenNumber, num: sum}
				return &SExpr{atom: tok, car: nil, cdr: nil}, nil
			} else {
				return nil, ErrEval
			}
		}
		if expr.atom.literal == "CAR" {
			expr = expr.cdr
			if expr == nil || expr.isNil() || expr.cdr.atom != nil {
				return nil, ErrEval
			}
			if expr.atom.literal == "NIL" && expr.cdr != nil && expr.cdr.isNil() {
				return expr.cdr, nil
			}

			expr = expr.car
			if expr == nil || expr.cdr == nil || expr.atom.typ != tokenQuote {
				return nil, ErrEval
			}

			expr = expr.cdr
			stmt := expr
			for expr != nil {
				stmt = expr
				expr = expr.car
			}
			return stmt, nil
		}
		if expr.atom.literal == "CDR" {
			expr = expr.cdr
			if expr == nil || expr.isNil() {
				return nil, ErrEval
			}
			if expr.atom.literal == "NIL" && expr.cdr != nil && expr.cdr.isNil() {
				return expr.cdr, nil
			}

			expr = expr.car
			if expr == nil || expr.atom.typ != tokenQuote {
				return nil, ErrEval
			}

			expr = expr.cdr
			stmt := expr
			for expr != nil {
				stmt = expr
				if expr.cdr != nil && expr.cdr.atom == nil {
					expr = expr.car
				} else {
					expr = expr.cdr
					if expr != nil {
						stmt = expr
						break
					}
				}
			}
			return stmt, nil
		}
		if expr.atom.literal == "CONS" {
			expr = expr.cdr
			if expr == nil || expr.car == nil {
				return nil, ErrEval
			}

			track++
			stmt1, err := expr.car.Eval()
			track--
			if err != nil {
				return nil, ErrEval
			}

			expr = expr.cdr
			if expr == nil || expr.cdr.atom != nil {
				return nil, ErrEval
			}

			expr = expr.car
			track++
			stmt2, err := expr.Eval()
			track--
			if err != nil {
				return nil, ErrEval
			}
			return &SExpr{atom: stmt1.atom, car: stmt1, cdr: stmt2}, nil
		}
		if expr.atom.literal == "LENGTH" {
			if expr.cdr.isNil() {
				return nil, ErrEval
			}

			sum := big.NewInt(0)
			if expr.cdr.car == nil || expr.cdr.car.cdr == nil {
				return nil, ErrEval
			}

			temp := expr.cdr.car.cdr.car
			if temp == nil {
				return nil, ErrEval
			}
			if temp.isNil() {
				return mkNumber(sum), nil
			}

			for {
				sum.Add(sum, big.NewInt(1))
				temp = temp.cdr
				if temp == nil {
					return nil, ErrEval
				}
				if temp.isNil() {
					break
				}
			}
			return mkNumber(sum), nil
		}

		// unary predicates: ATOM, LISTP, ZEROP
		if expr.atom.literal == "ATOM" {
			expr = expr.cdr
			if expr.cdr == nil || expr.isNil() {
				return nil, ErrEval
			}
			if !expr.cdr.isNil() && expr.cdr.atom.literal != "NIL" {
				return nil, ErrEval
			}
			if expr != nil {
				expr = expr.car
				track++
				stmt, err := expr.Eval()
				track--
				if err != nil {
					return nil, ErrEval
				}
				if stmt.isAtom() {
					tok := &token{typ: tokenSymbol, literal: "T"}
					return &SExpr{atom: tok, car: nil, cdr: nil}, nil
				} else {
					return &SExpr{atom: nil, car: nil, cdr: nil}, nil
				}
			}
		}
		if expr.atom.literal == "LISTP" {
			expr = expr.cdr
			if expr == nil || expr.atom == nil && expr.car == nil && expr.cdr == nil {
				return nil, ErrEval
			}
			if expr.cdr.atom != nil && expr.cdr.atom.literal != "NIL" {
				return nil, ErrEval
			}
			expr = expr.car
			track++
			stmt, err := expr.Eval()
			track--
			if err != nil {
				return nil, ErrEval
			}
			if (stmt.atom == nil || stmt.atom.literal == "NIL") && stmt.car == nil && stmt.cdr == nil {
				tok := &token{typ: tokenSymbol, literal: "T"}
				return &SExpr{atom: tok, car: nil, cdr: nil}, nil
			}
			if stmt.cdr == nil {
				return &SExpr{atom: nil, car: nil, cdr: nil}, nil
			} else {
				tok := &token{typ: tokenSymbol, literal: "T"}
				return &SExpr{atom: tok, car: nil, cdr: nil}, nil
			}
		}
		if expr.atom.literal == "ZEROP" {
			expr = expr.cdr
			if expr == nil || expr.cdr == nil || (!expr.cdr.isNil() && expr.cdr.atom.literal != "NIL") {
				return nil, ErrEval
			}
			if expr.atom == nil || (expr.car.atom.typ == tokenNumber && !expr.car.isAtom()) {
				return nil, ErrEval
			}

			track++
			stmt, err := expr.Eval()
			track--
			if err != nil {
				return nil, ErrEval
			}

			if stmt.atom.typ == tokenNumber && stmt.atom.num.Cmp(big.NewInt(0)) == 0 {
				tok := &token{typ: tokenSymbol, literal: "T"}
				return &SExpr{atom: tok, car: nil, cdr: nil}, nil
			} else {
				return &SExpr{atom: nil, car: nil, cdr: nil}, nil
			}
		}
	}

	// quotations
	if expr.atom.literal == "QUOTE" {
		expr = expr.cdr
		if expr == nil || expr.cdr == nil || (expr.cdr.atom != nil && expr.cdr.atom.literal != "NIL") {
			return nil, ErrEval
		}
		expr = expr.car
		if expr != nil {
			return expr, nil
		}
	}
	return nil, ErrEval
}
