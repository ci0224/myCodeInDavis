reachable(Nfa, StartState, FinalState, Input) :- select(StartState,StartStates,[]),
				helper(Nfa, StartStates, FinalState, Input).

helper(Nfa, CurStates, FinalState, []) :- member(FinalState, CurStates).
helper(Nfa, CurStates, FinalState, Input) :- 
	prefix(Z,Input),
	length(Z,1), 
	member(X,Z),
	append(Z,SufInput,Input),
	member(OneCurState,CurStates),
	transition(Nfa,OneCurState,X,NSs),
	helper(Nfa, NSs, FinalState, SufInput).
