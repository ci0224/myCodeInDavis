% A list is a 1-D array of numbers.
% A matrix is a 2-D array of numbers, stored in row-major order.

% You may define helper functions here.
myhead([H|_],H).
ith([H|_],H,0).
ith([_|L],Item,I) :- 
    Ii is I-1, 
    ith(L,Item,Ii).
ij(M,Item,I,J) :- ith(M,Row,I),ith(Row,Item,J).
hasSameLength(M,Length,Length).
hasSameLength(M,Length,Count) :-
    ith(M,Item,Count),
    length(Item,Sublength),
    Sublength is Length,
    NextCount is Count+1,
    hasSameLength(M,Length,NextCount).

myfor(M,A,Mmax,Amax,Mmax,0).
myfor(M,A,Mmax,Amax,Mcount,Amax) :- 
    Mnext is Mcount+1,
    myfor(M,A,Mmax,Amax,Mnext,0).

myfor(M,A,Mmax,Amax,Mcount,Acount) :-
    ij(M,Mij,Mcount,Acount),
    ij(A,Mij,Acount,Mcount),
    Anext is Acount+1,
    myfor(M,A,Mmax,Amax,Mcount,Anext).



% are_adjacent(List, A, B) returns true iff A and B are neighbors in List.
are_adjacent([A|L], A, B) :- myhead(L,B).
are_adjacent([B|L], A, B) :- myhead(L,A).
are_adjacent([_|L], A, B) :- are_adjacent(L, A, B).


% matrix_transpose(Matrix, Answer) returns true iff Answer is the transpose of
% the 2D matrix Matrix.

matrix_transpose([], []).
matrix_transpose(Matrix, Answer) :- 
    length(Matrix, MLength),
    hasSameLength(Matrix,MLength,0),
    length(Answer, ALength),
    hasSameLength(Answer,ALength,0),
    ith(Answer,AnswerFirstRow,0),
    length(AnswerFirstRow,LAFR),
    LAFR is MLength,
    ith(Matrix,MatrixFirstRow,0),
    length(MatrixFirstRow,MAFR),
    MAFR is ALength,
    myfor(Matrix,Answer,MLength,ALength,0,0).



    

% are_neighbors(Matrix, A, B) returns true iff A and B are neighbors in the 2D
% matrix Matrix.
are_neighbors(Matrix, A, B) :-
    ij(Matrix,A,I,J),
    ij(Matrix,B,II,JJ),
    II is I,
    J is JJ+1.
are_neighbors(Matrix, A, B) :-
    ij(Matrix,A,I,J),
    ij(Matrix,B,II,JJ),
    II is I,
    J is JJ-1.
are_neighbors(Matrix, A, B) :-
    ij(Matrix,A,I,J),
    ij(Matrix,B,II,JJ),
    II is I+1,
    J is JJ.
are_neighbors(Matrix, A, B) :-
    ij(Matrix,A,I,J),
    ij(Matrix,B,II,JJ),
    II is I-1,
    J is JJ.
