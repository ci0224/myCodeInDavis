package matrix

// If needed, you may define helper functions here.

// AreAdjacent returns true iff a and b are adjacent in lst.
func AreAdjacent(lst []int, a, b int) bool {
	if len(lst) == 0{
		return false
	}
	isAdj := false
	for index, value := range lst{
		if index == len(lst) - 1{
			// if this is the last item in the list; skip it
			break
		}
		if value == a && lst[index+1] == b{
			// if this is a and next item is b, then a and b are adj
			isAdj = true
			break
		}
		if value == b && lst[index+1] == a{
			// if this is b and next item is a, then a and b are adj
			isAdj = true
			break
		}
	}
	return isAdj
}

// Transpose returns the transpose of the 2D matrix mat.
func Transpose(mat [][]int) [][]int {
	if len(mat) == 0{
		// if mat is a empty matrix, return itself
		return mat
	}

	lengthOfNewRow := len(mat[0])
	lengthOfNewCol := len(mat)

	newMat := make([][]int, lengthOfNewRow)

	for newColIndex := 0; newColIndex < lengthOfNewRow; newColIndex++ {
		newRow := make([]int, lengthOfNewCol)
		// iterate column of mat and store as new row
		for newRowIndex := 0; newRowIndex < lengthOfNewCol; newRowIndex++ {
			newRow[newRowIndex] = mat[newRowIndex][newColIndex]
		}
		// insert row in newMat
		newMat[newColIndex] = newRow
	}
	return newMat
}

// AreNeighbors returns true iff a and b are neighbors in the 2D matrix mat.
func AreNeighbors(mat [][]int, a, b int) bool {
	if len(mat) == 0{
		return false
	}

	isNeighbor := false
	for firstIndex, firstValue := range mat{
		if isNeighbor {
			break
		}
		for secondIndex, value := range firstValue{
			if secondIndex != len(mat[0]) - 1{
				// if right exist
				if value == a && mat[firstIndex][secondIndex+1] == b{
					isNeighbor = true
					break
				}
				if value == b && mat[firstIndex][secondIndex+1] == a{
					isNeighbor = true
					break
				}
			}
			if firstIndex != len(mat) - 1 {
				// if bottom exist
				if value == a && mat[firstIndex+1][secondIndex] == b{
					isNeighbor = true
					break
				}
				if value == b && mat[firstIndex+1][secondIndex] == a{
					isNeighbor = true
					break
				}
			}

		}
	}
	return isNeighbor
}