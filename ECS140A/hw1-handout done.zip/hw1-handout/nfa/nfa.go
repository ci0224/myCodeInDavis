package nfa

// A state in the NFA is labeled by a single integer.
type state uint

// TransitionFunction tells us, given a current state and some symbol, which
// other states the NFA can move to.
//
// Deterministic automata have only one possible destination state,
// but we're working with non-deterministic automata.
type TransitionFunction func(st state, act rune) []state

// You may define helper functions here.

func Reachable(
	// `transitions` tells us what our NFA looks like
	transitions TransitionFunction,
	// `start` and `final` tell us where to start, and where we want to end up
	start, final state,
	// `input` is a (possible empty) list of symbols to apply.
	input []rune,
) bool {
	// TODO: Write the Reachable function,
	// return true if the nfa accepts the input and can reach the final state with that input,
	// return false otherwise

	n := len(input)

	if n == 0 {
		// if there is no input ...
		if start == final{
			return true
		} else {
			return false
		}
	}

	inputIndex := 0
	// reach is a map that collecting all the current achievable states
	// in other words, if map[x] == true, then x is a current achievable state
	reached := make(map[state]bool)
	reached[start] = true
	for n >= 1 {
		currentInput := input[inputIndex]
		newReached := make(map[state]bool)
		for _state, _ := range reached {
			nextStates := transitions(_state, currentInput)
			// nextStates is a state array that contains all states
			//      we can achieve when taking _state as current state
			for _, _state := range nextStates {
				newReached[_state] = true
			}
		}
		reached = newReached
		inputIndex += 1
		n -= 1
	}

	return reached[final]

}

