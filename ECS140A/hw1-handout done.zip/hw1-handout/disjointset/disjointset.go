package disjointset

// DisjointSet is the interface for the disjoint-set (or union-find) data
// structure.
// Do not change the definition of this interface.
type DisjointSet interface {
	// UnionSet(s, t) merges (unions) the sets containing s and t,
	// and returns the representative of the resulting merged set.
	UnionSet(int, int) int
	// FindSet(s) returns representative of the class that s belongs to.
	FindSet(int) int
}

// TODO: implement a type that satisfies the DisjointSet interface.

type Set struct {
	value map[int]int
}

func (set Set) UnionSet (a int, b int) int {
	root_a := set.FindSet(a)
	root_b := set.FindSet(b)

	set.value[root_b] = root_a
	set.value[b] = root_a
	return root_a
}

func (set Set) FindSet (target int) int {
	if rep, exist := set.value[target]; !exist || rep == target {
		return target
	}
	c := set.FindSet(set.value[target])
	set.value[target] = c
	return c
}

// NewDisjointSet creates a struct of a type that satisfies the DisjointSet interface.
func NewDisjointSet() DisjointSet {
	temp := Set{make(map[int]int)}
	return temp
}
