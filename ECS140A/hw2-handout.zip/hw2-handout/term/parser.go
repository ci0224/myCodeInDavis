package term

import (
	"errors"
)

// ErrParser is the error value returned by the Parser if the string is not a
// valid term.
// See also https://golang.org/pkg/errors/#New
// and // https://golang.org/pkg/builtin/#error
var ErrParser = errors.New("parser error")

// original grammar
// <start>    ::= <term> | \epsilon
// <term>     ::= ATOM | NUM | VAR | <compound>
// <compound> ::= <functor> LPAR <args> RPAR
// <functor>  ::= ATOM
// <args>     ::= <term> | <term> COMMA <args>



// LL(1) grammar for the G language
// <start>    	::= <term> | \epsilon
// <term>     	::= ATOM <afterATOM> | NUM | VAR
// <afterATOM>	::= LPAR <args> RPAR | \epsilon
// <args>     	::= <term> <afterTerm>
// <afterTerm>	::= COMMA <args> | \epsilon



// FIRST FOLLOW TABLE
// 				|			FIRST						|			FOLLOW			||
// 				|										|							||
// <start>		|	\epsilon, ATOM, NUM, VAR			|	$						||
// 				|										|							||
// <term>		|	ATOM, NUM, VAR						|	LPAR, \epsilon, $		|| x
// 				|										|							||
// <afterATOM>	|	LPAR, \epsilon						|	\epsilon				|| x
// 				|										|							||
// <args>		|	ATOM, NUM, VAR						|	RPAR, COMMA				|| x
// 				|										|							||
// <afterTerm>	|	COMMA, \epsilon						|	RPAR					|| x
// 				|										|							||



// parser table
// 				|				ATOM				|			NUM				|		VAR				|  LPAR							|
// 				|									|							|						|								|
// <start>		| 	<start> -> <term>				|	<start> -> <term>		|<start> -> <term>		|	<start> -> <term>				|
// 				|									|							|						|								|
// <term>		| 	<term> -> ATOM <afterATOM>		|	<term> -> NUM			|	<term> -> VAR		|	<term> -> ATOM <afterATOM>	|
// 				|									|							|						|								|
// <afterATOM>	|  									|							|  						| <afterATOM> -> LPAR <args> RPAR  	|
// 				|									|							|						|								||
// <args>		|  	<args> -> <term> <afterTerm>	| <args>-><term> <afterTerm>|<args>-><term> <afterTerm>|							||
// 				|									|							|						|								||
// <afterTerm>	|  									| 							|  						|								||
// 				|									|							|						|						||



// 				|				COMMA				| 		RPAR
// 				|									|
// <afterTerm>	| 	<afterTerm>	-> COMMA <args>		|	<afterTerm>	-> \epsilon
// 				|									|
// <args>		| 	<args> -> <term> <afterTerm>	|	<args> -> <term> <afterTerm>





// Parser is the interface for the term parser.
// Do not change the definition of this interface.
type Parser interface {
	Parse(string) (*Term, error)
}
// NewParser creates a struct of a type that satisfies the Parser interface.
func NewParser() Parser {
	return &Parse{}
}

// CODE CHUNK START
type Parse struct {
	lex *lexer
	peekTok *Token
}

func (p *Parse) nextToken() (*Token, error) {
	if tok := p.peekTok; tok != nil {
		p.peekTok = nil
		return tok, nil
	}

	tok, err := p.lex.next()
	if err != nil {
		return nil, ErrParser
	}

	return tok, nil
}

func (p *Parse) backToken(tok *Token) {
	p.peekTok = tok
}

func (p *Parse) peekToken() (*Token, error) {
	tok, err := p.nextToken()
	if err != nil {
		return nil, ErrParser
	}

	p.backToken(tok)

	return tok, nil
}
// CODE CHUNK END
// This chunk of code is from the brackets/parser.go


// Implement the Parse method of the Parser interface for ParserImpl.
// Parse the non-terminal <start>.
// <start> ::= <term>
func (p *Parse) Parse(input string) (*Term, error) {
	p.lex = newLexer(input)

	// <start> -> <term>
	// Parse <term>.
	token, err := p.peekToken()
	if err != nil {
		return nil, ErrParser
	}

	if token.typ == tokenEOF {
		return nil, nil
	}

	term, err := p.termNT()
	if err != nil {
		return nil, ErrParser
	}
	// FOLLOW(<start>) = $
	// Check the next token is the endmarker $, there should be nothing left
	// after parsing <start>.
	if nextTok, err := p.nextToken(); err != nil || nextTok.typ != tokenEOF {
		return nil, ErrParser
	}

	return term, nil
}

// Parse the non-terminal <term>.
// <term> ::= ATOM <afterATOM> | NUM | VAR
func (p *Parse) termNT() (*Term, error) {

	// <term> -> ATOM <afterATOM> | NUM | VAR
	// so there are three cases:  ATOM <afterATOM> | NUM | VAR
	tok, err := p.nextToken()
	if err != nil  {
		return nil, ErrParser
	}
	switch tok.typ {
	// ATOM <afterATOM>
	case tokenAtom:
		expr := &Term{Typ: TermAtom, Literal: tok.literal}
		token, err := p.peekToken()
		// if next is not a valid token
		if err != nil  {
			return nil, ErrParser
		}
		// if next is EOF, it is not a compound
		if token.typ == tokenEOF{
			return expr, nil
		}
		// else this is a compound
		followingArgs, err := p.afterATOM()
		if err != nil  {
			return nil, ErrParser
		}
		return &Term{Typ: TermCompound, Functor: expr, Args: followingArgs}, nil
	// NUM
	case tokenNumber:
		return &Term{Typ: TermNumber, Literal: tok.literal}, nil
	// VAR
	case tokenVariable:
		return &Term{Typ: TermVariable, Literal: tok.literal}, nil
	default:
		return nil, ErrParser
	}
}

// Parse the non-terminal <args>.
// <afterATOM> ::= LPAR <args> RPAR | \epsilon
// TODO: epsilon????????
func (p *Parse) afterATOM() ([]*Term, error) {
	// Consume L
	token, err := p.nextToken()
	if err != nil || token.typ != tokenLpar{
		return nil, ErrParser
	}
	expr, err := p.argsNT()
	if err != nil {
		return nil, ErrParser
	}
	// Consume R
	token, err = p.nextToken()
	if err != nil || token.typ != tokenRpar{
		return nil, ErrParser
	}

	return expr, nil
}

// Parse the non-terminal <args>.
//  <args> 	::= <term> <afterTerm>
func (p *Parse) argsNT() ([]*Term, error) {
	// parse terms
	var result []*Term

	term, err := p.termNT()
	if err != nil {
		return nil, ErrParser
	}
	result = append(result, term)
	afterTerm, err := p.afterTermNT()
	if err != nil {
		return nil, ErrParser
	}
	/*
	if afterTerm != nil {
		for i:= 0 ; i<afterTerm.length; i++ {
			result = append(result, afterTerm[i])
		}
	}
	*/
	afterTerm = append([]*Term{term}, afterTerm...)

	return afterTerm, nil
	// 7 : "f(X)", passed
	// 8 : "foo  ( a , X )", failed

}

// Parse the non-terminal <afterTerm>.
// <afterTerm> ::= COMMA <args> | \epsilon
func (p *Parse) afterTermNT() ([]*Term, error) {
	// There are two cases, so we peek the next token.
	tok, err := p.peekToken()
	if err != nil {
		return nil, ErrParser
	}

	switch tok.typ {
		case tokenComma:
			tok, err = p.nextToken()
			if err != nil {
				return nil, ErrParser
			}
			args, err := p.argsNT() // this is a ([]*Term, error)
			if err != nil {
				return nil, ErrParser
			}
			return args, nil
		// case tokenEOF
		case tokenRpar:
			return nil, nil
	default:
		return nil, ErrParser

	}
}
