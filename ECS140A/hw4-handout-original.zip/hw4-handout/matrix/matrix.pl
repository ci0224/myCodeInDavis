% A list is a 1-D array of numbers.
% A matrix is a 2-D array of numbers, stored in row-major order.

% You may define helper functions here.

% are_adjacent(List, A, B) returns true iff A and B are neighbors in List.
are_adjacent(List, A, B) :-
    %% TODO: remove fail and add body/other cases for this predicate
    fail.

% matrix_transpose(Matrix, Answer) returns true iff Answer is the transpose of
% the 2D matrix Matrix.
matrix_transpose(Matrix, Answer) :-
    %% TODO: remove fail and add body/other cases for this predicate
    fail.

% are_neighbors(Matrix, A, B) returns true iff A and B are neighbors in the 2D
% matrix Matrix.
are_neighbors(Matrix, A, B) :-
    %% TODO: remove fail and add body/other cases for this predicate
    fail.
